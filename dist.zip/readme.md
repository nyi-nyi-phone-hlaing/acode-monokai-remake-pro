## Monokai Remake Pro 🌈

Acode Monokai Remake Pro is a plugin designed for the Acode editor, based on the popular Monokai Theme VS Code theme. This plugin is perfect for developers who are looking for a sleek and modern look and feel for their code editor.

 <details> 
     <summary><strong>Updates</strong></summary> 
     <br> 
     <details> 
         <summary> 
             <code><strong>v1.0.0</strong></code> 
         </summary> 
         <ul> 
             <li>First Release</li> 
         </ul> 
     </details> 
 </details> 
  
  
 ### How to Use ✨ 
  
 1. Install the Acode editor if you haven't already. 
 2. Install the Acode Monokai Remake Pro plugin from the plugin store(Acode > Settings > Plugins). 
 3. Follow the instructions in the documentation to enable the desired theme. 
 4. Enjoy a sleek and modern look and feel for your code editor with Acode Monokai Remake Pro!

> Bug Report - [Telegram](https://t.me/figarland_mhan_gyi)

### Choosing the Theme:

For choosing this theme follow given steps:

- Open Acode App > Settings > Themes
- And Select Editor Section and scroll to bottom
- there you can get theme: Monokai Remake Pro
- You can select Monokai Remake Pro

## Note

- function myFunc(a,b,c) have underline
- all function call have underline

HOPE YOU ENJOY IT 🌈💫✨
